#!/bin/bash
# Build the application during deployment
cd /var/app/staging
npm run build
