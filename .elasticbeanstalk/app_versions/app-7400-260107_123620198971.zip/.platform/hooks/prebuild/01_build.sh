#!/bin/bash
# Build the application during deployment
cd /var/app/staging
npm install --include=dev
npm run build
